<?php if(!$this->tpl_var['userhash']){ ?>
<?php $this->_compileInclude('header'); ?>
<body>
<?php $this->_compileInclude('nav'); ?>
<?php } ?>
<div class="container-fluid" id="datacontent">
	<div class="row-fluid">
		<div class="main box itembox">
			<ul class="breadcrumb">
				<li>
					<span class="icon-home"></span> <a href="index.php?exam">考场选择</a>
				</li>
				<li>
					<a href="index.php?exam-app-basics-open">开通考场</a>
				</li>
				<li class="active">
					<?php echo $this->tpl_var['basic']['basic']; ?>
				</li>
			</ul>
		</div>
		<div class="main box itembox">
			<h4 class="title">开通考场</h4>
			<div class="col-xs-1"></div>
			<div class="col-xs-3" style="padding-top:30px;">
				<div class="thumbnail"><img alt="300x200" src="<?php if($this->tpl_var['basic']['basicthumb']){ ?><?php echo $this->tpl_var['basic']['basicthumb']; ?><?php } else { ?>app/exam/styles/image/paper.png<?php } ?>" /></div>
			</div>
			<div class="col-xs-1"></div>
			<div class="col-xs-7">
				<div class="caption">
					<h3><?php echo $this->tpl_var['basic']['basic']; ?></h3>
					<p>&nbsp;</p>
					<p>科目：<?php echo $this->tpl_var['subjects'][$this->tpl_var['basic']['basicsubjectid']]['subject']; ?></p>
					<p>班级：<?php echo $this->tpl_var['classess'][$this->tpl_var['basic']['basicclassesid']]['classes']; ?></p>
					
					<?php if($this->tpl_var['isopen']){ ?><p>到期时间：<?php echo date('Y-m-d',$this->tpl_var['isopen']['obendtime']); ?></p><?php } ?>
				</div>
				<div>&nbsp;</div>
				<?php if(!$this->tpl_var['isopen']){ ?>
				<form action="index.php?exam-app-basics-openit" method="post">
				<p>
					<input value="<?php echo $this->tpl_var['basic']['basicid']; ?>" name="basicid" type="hidden"/>
					<input class="btn btn-primary" value="开通" type="submit"/>
				</p>
				</form>
				<?php } else { ?>
				<p>
					<a class="btn btn-primary ajax" href="index.php?exam-app-index-setCurrentBasic&basicid=<?php echo $this->tpl_var['basic']['basicid']; ?>">进入考场</a>
				</p>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<form aria-hidden="true" id="myModal" method="post" class="modal fade" role="dialog" aria-labelledby="#myModalLabel" action="index.php?exam-app-basics-coupon">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			
		</div>
	</div>
</form>
<?php $this->_compileInclude('footer'); ?>
</body>
</html>