<footer class="container-fluid text-center" style="background-color:#337AB7;">
	<p style="padding:1rem;">
		Copyright © 中国矿业大学 2015-2017
	</p>
</footer>