<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>工程管理专业智慧课堂</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes" />
<script src="app/core/styles/js/fastclick.js"></script>
<link rel="stylesheet" type="text/css" href="app/core/styles/css/swiper.min.css" />
<link rel="stylesheet" type="text/css" href="app/core/styles/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="app/core/styles/css/mskin.css" />
<script src="app/core/styles/js/jquery.min.js"></script>
<script src="app/core/styles/js/swiper.jquery.js"></script>
<script src="app/core/styles/js/jquery.json.js"></script>
<script src="app/core/styles/js/jquery.mobile.custom.min.js"></script>
<script src="app/core/styles/js/bootstrap.min.js"></script>
<script src="app/core/styles/js/all.fine-uploader.min.js"></script>
<script src="app/core/styles/js/mplugin.js"></script>
<script src="app/exam/styles/js/mplugin.js"></script>
</head>