<?php
/*
 * Created on 2013-5-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class config_content
{
	public $fields = array('contentid','contentcatid','contentmoduleid','contentuserid','contentusername','contenttitle','contentthumb','contentlink','contentinputtime','contentmodifytime','contentsequence','contentdescribe','contentstatus','contenttemplate','contenttext');
}
?>
