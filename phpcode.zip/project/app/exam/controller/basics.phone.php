<?php
/*
 * Created on 2016-5-19
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class action extends app
{
	public function display()
	{
		$action = $this->ev->url(3);
		if(!method_exists($this,$action))
		$action = "index";
		$this->$action();
		exit;
	}

	private function openit()
	{
		$basicid = $this->ev->get('basicid');
		$basic = $this->basic->getBasicById($basicid);
		if(!$basic)
		{
			$message = array(
				'statusCode' => 300,
				"message" => "操作失败，此考场不存在"
			);
			$this->G->R($message);
		}
		$userid = $this->_user['sessionuserid'];
		if($this->basic->getOpenBasicByUseridAndBasicid($userid,$basicid))
		{
			$message = array(
				'statusCode' => 300,
				"message" => "您已经开通了本考场"
			);
		}
        $time = 365*24*3600;
		// if($basic['basicdemo'])
		// {
			// $time = 365*24*3600;
		// }
		// else
		// {
			// $opentype = intval($this->ev->get('opentype'));
			// $time = $t['time']*24*3600;
			// $user = $this->user->getUserById($this->_user['sessionuserid']);
		// }
		$args = array('obuserid'=>$userid,'obbasicid'=>$basicid,'obendtime'=>TIME + $time);
		$this->basic->openBasic($args);
		$message = array(
			'statusCode' => 200,
			"message" => "操作成功",
			"callbackType" => "forward",
		    "forwardUrl" => "index.php?exam-phone"
		);
		$this->G->R($message);
	}

	

	private function detail()
	{
		$this->basic->delOpenPassBasic($this->_user['sessionuserid']);
		$this->classes = $this->G->make('classes','exam');
		$basicid = $this->ev->get('basicid');
		$basic = $this->basic->getBasicById($basicid);
		$classess = $this->classes->getClassesList();
		$isopen = $this->basic->getOpenBasicByUseridAndBasicid($this->_user['sessionuserid'],$basicid);
		$this->tpl->assign('isopen',$isopen);
		$this->tpl->assign('classess',$classess);
		$this->tpl->assign('basic',$basic);
		$this->tpl->display('basics_detail');
	}

	private function open()
	{
		$this->classes = $this->G->make('classes','exam');
		$search = $this->ev->get('search');
		$page = $page > 1?$page:1;
		$subjects = $this->basic->getSubjectList();
		if(!$search)
		$args = 1;
		else
		{
			$args = array();
			// if($search['basicdemo'])$args[] = array("AND","basicdemo = :basicdemo",'basicdemo',$search['basicdemo']);
			if($search['keyword'])$args[] = array("AND","basic LIKE :basic",'basic',"%{$search['keyword']}%");
			if($search['basicclassesid'])$args[] = array("AND","basicclassesid = :basicclassesid","basicclassesid",$search['basicclassesid']);
			if($search['basicsubjectid'])$args[] = array("AND","basicsubjectid = :basicsubjectid",'basicsubjectid',$search['basicsubjectid']);
			if($search['basicapi'])$args[] = array("AND","basicapi = :basicapi",'basicapi',$search['basicapi']);
		}
		$basics = $this->basic->getBasicList($page,20,$args);
		$classess = $this->classes->getClassesList();
		$this->tpl->assign('search',$search);
		$this->tpl->assign('classess',$classess);
		$this->tpl->assign('subjects',$subjects);
		$this->tpl->assign('basics',$basics);
		$this->tpl->display('basics_open');
	}

	private function index()
	{
		if(!$this->data['openbasics'])exit(header("location:index.php?exam-app"));
		$this->tpl->display('basics');
	}
}


?>
