<?php

class classes_exam
{
	public $G;

	public function __construct(&$G)
	{
		$this->G = $G;
		$this->pdosql = $this->G->make('pdosql');
		$this->sql = $this->G->make('sql');
		$this->db = $this->G->make('pepdo');
		$this->pg = $this->G->make('pg');
		$this->ev = $this->G->make('ev');
	}

	//获取班级列表
	//参数：无
	//返回值：班级列表
	public function getClassesList()
	{
		$data = array(false,'classes','1',false,'classesid ASC');
		$sql = $this->pdosql->makeSelect($data);
		return $this->db->fetchAll($sql,'classesid');
	}

	//按页获取班级列表
	//参数：无
	//返回值：班级列表
	public function getClassesListByPage($page,$number = 20)
	{
		$data = array(
			'select' => false,
			'table' => 'classes',
			'query' => 1,
			'index' => 'classesid'
		);
		$r = $this->db->listElements($page,$number,$data);
		return $r;
	}

	//根据班级查询
	//参数：班级字符串
	//返回值：该班级信息数组
	public function getClassesByName($classes)
	{
		$data = array(false,'classes',array(array("AND","classes = :classes",'classes',$classes)),false,false,false);
		$sql = $this->pdosql->makeSelect($data);
		return $this->db->fetch($sql);
	}

	//根据ID获取班级信息
	//参数：班级编号
	//返回值：该班级信息数组
	public function getClassesById($classesid)
	{
		$data = array(false,'classes',array(array("AND","classesid = :classesid",'classesid',$classesid)));
		$sql = $this->pdosql->makeSelect($data);
		return $this->db->fetch($sql);
	}

	//修改班级信息
	//参数：班级编号,要修改的信息
	//返回值：true
	public function modifyClasses($args)
	{
		$data = array('classes',$args,"AND",$classesid);
		$sql = $this->pdosql->makeUpdate($data);
		$this->db->exec($sql);
		return true;
	}

	//增加班级
	//参数：要添加的班级的信息数组
	//返回值：班级编号
	public function addClasses($args)
	{
		$data = array(false,'classes',"AND",$args['classesid']);
		$sql = $this->pdosql->makeSelect($data);
		if($this->db->fetch($sql))return false;
		$data = array('classes',$args);
		$sql = $this->pdosql->makeInsert($data);
		$this->db->exec($sql);
		return $args['classesid'];
	}

	//删除班级
	//参数：班级编号
	//返回值：受影响的记录数
	public function delClasses($id)
	{
		$data = array('classes',array(array("AND","classesid = :classesid",'classesid',$id)));
		$sql = $this->pdosql->makeDelete($data);
		$this->db->exec($sql);
		return $this->db->affectedRows();
	}
}

?>
