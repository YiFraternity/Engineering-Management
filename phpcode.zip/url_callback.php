<?php
    include("access_token.php");
    include_once "php/WXBizMsgCrypt.class.php";

    $encodingAesKey="lzjmtolnLBARYpPHsjEjBh9CBaDcd9IssW8fwHhVqfF";
    $token="wechat";
    $corpid="ww84add34777d58433";

    // 公众号服务器数据
    $sReqMsgSig =  urldecode($_GET['msg_signature']);
    $sReqTimeStamp = urldecode($_GET['timestamp']);
    $sReqNonce = urldecode($_GET['nonce']);
    $sReqData = file_get_contents("php://input");
    global $sEncrytMsg;//xml格式的密文

    $wxcpt = new WXBizMsgCrypt($token, $encodingAesKey, $corpid);

    $sVerifyMsgSig =  ($_GET['msg_signature']);//签名串，对应URL参数的msg_signature
    $sVerifyTimeStamp = ($_GET['timestamp']);//时间戳 对应URL参数的timestamp
    $sVerifyNonce = ($_GET['nonce']);//随机串
    $sVerifyEchoStr = ($_GET['echostr']);//随机串，对应URL参数的echostr

    $sEchoStr = 123;//解密后的echostr
    $errCode = $wxcpt->VerifyURL($sVerifyMsgSig, $sVerifyTimeStamp, $sVerifyNonce, $sVerifyEchoStr, $sEchoStr);
    if ($errCode == 0) {
        echo $sEchoStr;
        exit(0);
    } else {
        print($errCode . "\n\n");
    }

    /**
     * 检验消息的真实性，并且获取解密后的明文.
     * <ol>
     *    <li>利用收到的密文生成安全签名，进行签名验证</li>
     *    <li>若验证通过，则提取xml中的加密消息</li>
     *    <li>对消息进行解密</li>
     * </ol>
     *
     * @param $sReqMsgSig string 签名串，对应URL参数的msg_signature
     * @param $sReqTimeStamp string 时间戳 对应URL参数的timestamp
     * @param $sReqNonce string 随机串，对应URL参数的nonce
     * @param $sReqData string 密文，对应POST请求的数据
     * @param &$sMsg string 解密后的原文，当return返回0时有效
     *
     */
    $sMsg="";//解析之后的明文
    $errCode = $wxcpt->DecryptMsg($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sReqData, $sMsg);
    if ($errCode == 0)
    {
        $xml = new DOMDocument();
        $xml->loadXML($sMsg);
        $reqToUserName = $xml->getElementsByTagName('ToUserName')->item(0)->nodeValue;
        $reqFromUserName = $xml->getElementsByTagName('FromUserName')->item(0)->nodeValue;
        $reqCreateTime = $xml->getElementsByTagName('CreateTime')->item(0)->nodeValue;
        $reqMsgType = $xml->getElementsByTagName('MsgType')->item(0)->nodeValue;
        $reqContent = $xml->getElementsByTagName('Content')->item(0)->nodeValue;
        $reqEventKey = $xml->getElementsByTagName('EventKey')->item(0)->nodeValue;
        $reqMsgId = $xml->getElementsByTagName('MsgId')->item(0)->nodeValue;
        $reqAgentID = $xml->getElementsByTagName('AgentID')->item(0)->nodeValue;
        if($reqMsgType=="event" && $reqEventKey=="exam_system"){
            $title="考试";
            $description="";
            $picurl="http://www.pm2005.cn/images/project.jpg";
            $url="http://www.pm2005.cn/project/index.php?content-phone";
            $resultStr = "<xml>
                        <ToUserName><![CDATA[$reqFromUserName]]></ToUserName>
                        <FromUserName><![CDATA[$corpid]]></FromUserName>
                        <CreateTime>$sReqTimeStamp</CreateTime>
                        <MsgType><![CDATA[news]]></MsgType>
                        <ArticleCount>1</ArticleCount>
                        <Articles>
                        <item>
                        <Title><![CDATA[$title]]></Title>
                        <Description><![CDATA[$description]]></Description>
                        <PicUrl><![CDATA[$picurl]]></PicUrl>
                        <Url><![CDATA[$url]]></Url>
                        </item>
                        </Articles>
                        </xml>";

            $sEncrytMsg="";//xml格式的密文
            $errCode=$wxcpt->EncryptMsg($resultStr,$sReqTimeStamp,$sReqNonce,$sEncrytMsg);
            if ($errCode == 0) {
                // file_put_contents('smg_response.txt', $sEncryptMsg); //debug:查看smg
                print($sEncryptMsg);
            } else {
                print($errCode . "\n\n");
            }
        }
        /**
        EncryptMsg($resultStr,$sReqTimeStamp,$sReqNonce,$sEncrytMsg){}
        * 将公众平台回复用户的消息加密打包.
        * <ol>
        *    <li>对要发送的消息进行AES-CBC加密</li>
        *    <li>生成安全签名</li>
        *    <li>将消息密文和安全签名打包成xml格式</li>
        * </ol>
        *
        * @param $resultStr string 公众平台待回复用户的消息，xml格式的字符串
        * @param $sReqTimeStamp string 时间戳，可以自己生成，也可以用URL参数的timestamp
        * @param $sReqNonce string 随机串，可以自己生成，也可以用URL参数的nonce
        * @param &$sEncrytMsg string 加密后的可以直接回复用户的密文，包括msg_signature, timestamp, nonce, encrypt的xml格式的字符串,
        *                      当return返回0时有效
        *
        */
        if($reqMsgType =="text"){
            $contentStr="你好，你发的消息是".$reqContent;
            $resultStr = "<xml>
                            <ToUserName><![CDATA[%S]]></ToUserName>
                            <FromUserName><![CDATA[%s]]></FromUserName>
                            <CreateTime>%s</CreateTime>
                            <MsgType><![CDATA[text]]></MsgType>
                            <Content><![CDATA[%s]]></Content>
                            </xml>";
            $resultStr=sprintf($resultStr,$reqFromUserName,$corpid,$sReqTimeStamp,$contentStr);
        }
        $sEncryptMsg = ""; //xml格式的密文
        $errCode = $wxcpt->EncryptMsg($resultStr, $sReqTimeStamp, $sReqNonce, $sEncryptMsg);
        if ($errCode == 0) {
    // file_put_contents('smg_response.txt', $sEncryptMsg); //debug:查看smg
            print($sEncryptMsg);
        } else {
            print($errCode . "\n\n");
        }
    } else {
        print($errCode . "\n\n");
    }
?>